import { useState } from 'react';
import shortid from 'shortid';
import Link from 'next/link';

export default function CreateSmartlink() {
    const [trackName, setTrackName] = useState('');
    const [artistName, setArtistName] = useState('');
    const [smartlink, setSmartlink] = useState(null);

    const generateSmartlink = () => {
        if (!trackName || !artistName) return;
        const slug = shortid.generate();
        setSmartlink(`/link/${slug}`);
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-[#121212] text-white p-6">
            <h2 className="text-3xl font-semibold">Create a Smartlink</h2>
            <div className="mt-6 w-full max-w-md">
                <input
                    type="text"
                    placeholder="Track Name"
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded text-white mb-3"
                    value={trackName}
                    onChange={(e) => setTrackName(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Artist Name"
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded text-white mb-3"
                    value={artistName}
                    onChange={(e) => setArtistName(e.target.value)}
                />
                <button className="w-full bg-[#F8CF69] text-black font-semibold p-3 rounded hover:bg-yellow-500" onClick={generateSmartlink}>
                    Generate Link
                </button>
            </div>

            {smartlink && (
                <div className="mt-6 p-4 bg-gray-800 shadow rounded">
                    <p className="text-gray-300">Your Smartlink:</p>
                    <Link href={smartlink}>
                        <span className="text-yellow-400 cursor-pointer">{`eldistro.link${smartlink}`}</span>
                    </Link>
                </div>
            )}
        </div>
    );
}