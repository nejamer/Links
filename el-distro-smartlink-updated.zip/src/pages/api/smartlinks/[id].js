export default function handler(req, res) {
    const { id } = req.query;

    // Simulated response (This should be replaced with a real database lookup)
    const sampleLinks = {
        "example123": [
            { platform: "Spotify", url: "https://open.spotify.com/track/example" },
            { platform: "Apple Music", url: "https://music.apple.com/us/album/example" },
            { platform: "YouTube", url: "https://youtube.com/watch?v=example" },
            { platform: "Deezer", url: "https://www.deezer.com/track/example" },
        ]
    };

    res.status(200).json({ links: sampleLinks[id] || [] });
}