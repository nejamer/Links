import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function SmartlinkPage() {
    const router = useRouter();
    const { id } = router.query;
    const [links, setLinks] = useState([]);

    useEffect(() => {
        if (id) {
            axios.get(`/api/smartlinks/${id}`)
                .then(response => setLinks(response.data.links))
                .catch(() => setLinks([]));
        }
    }, [id]);

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-[#121212] text-white p-6">
            <h2 className="text-3xl font-semibold">Listen Now</h2>
            <p className="text-gray-400">Choose your preferred platform:</p>
            <div className="mt-6 w-full max-w-md">
                {links.length > 0 ? (
                    links.map((link, index) => (
                        <a key={index} href={link.url} target="_blank" rel="noopener noreferrer" 
                            className="block p-3 bg-gray-800 border border-gray-600 text-white rounded mt-2 hover:bg-gray-700">
                            {link.platform}
                        </a>
                    ))
                ) : (
                    <p className="text-gray-500">Fetching links...</p>
                )}
            </div>
        </div>
    );
}