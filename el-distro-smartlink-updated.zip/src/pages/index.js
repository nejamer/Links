import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-[#121212] text-white">
            <Head>
                <title>El Distro Smartlinks</title>
            </Head>
            <h1 className="text-4xl font-bold">Create Your Music Smartlink</h1>
            <p className="mt-4 text-lg text-gray-400">Generate a single link to all streaming platforms.</p>
            <Link href="/create">
                <button className="mt-6 px-6 py-3 bg-[#F8CF69] text-black font-semibold rounded-md hover:bg-yellow-500">
                    Get Started
                </button>
            </Link>
        </div>
    );
}